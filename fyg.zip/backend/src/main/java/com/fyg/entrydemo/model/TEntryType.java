package com.fyg.entrydemo.model;

public enum TEntryType {
    BasicBankEntry,
    DistributionInterest,
    Dividend,
    Contribution,
    Investment
}
